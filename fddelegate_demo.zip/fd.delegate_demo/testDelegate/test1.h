#if !defined(__TEST1_H__INCLUDED__)
#define __TEST1_H__INCLUDED__

void test1();

#endif  // #if !defined(__TEST1_H__INCLUDED__)
