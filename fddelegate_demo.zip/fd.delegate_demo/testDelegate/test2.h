#if !defined(__TEST2_H__INCLUDED__)
#define __TEST2_H__INCLUDED__

void test2();

#endif  // #if !defined(__TEST2_H__INCLUDED__)
